LESSON TEMPLATE V3

Upload these files to the repository root:
- lesson-v3.css
- lesson-v3.js
- lesson-template-v3.html

This template also uses:
- atlas-terms.css
- atlas-terms.js

Those two Atlas Terms files must already be in the repository root.

Use lesson-template-v3.html as the locked master layout for all future Academy lessons.

The visual system keeps the olive, navy, cream, gold, and paper palette.
It does not use the old orange-heavy style.

Commit title:
Add locked Academy Lesson Template V3
