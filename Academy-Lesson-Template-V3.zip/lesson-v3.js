
document.addEventListener("DOMContentLoaded", () => {
  const quiz = document.querySelector("[data-quiz]");
  if (!quiz) return;

  const button = quiz.querySelector("[data-check-quiz]");
  const result = quiz.querySelector(".quiz-result");

  button.addEventListener("click", () => {
    let score = 0;
    const groups = [...quiz.querySelectorAll("[data-question]")];

    groups.forEach(group => {
      const selected = group.querySelector("input:checked");
      if (selected && selected.dataset.correct === "true") score++;
    });

    result.textContent = `You got ${score} of ${groups.length} correct.`;
  });
});
